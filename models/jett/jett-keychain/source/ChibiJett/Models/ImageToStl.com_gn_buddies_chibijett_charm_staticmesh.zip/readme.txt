感谢您使用ImageToStl。除此注释外，您还可以找到转换后的文件。

请访问 https://imagetostl.com 上的 ImageToStl，获取更多免费文件转换和在线查看工具。